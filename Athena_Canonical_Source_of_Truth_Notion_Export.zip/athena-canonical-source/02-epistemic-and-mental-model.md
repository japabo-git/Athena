# 02 — Epistemic & Mental Model

**Label:** CURRENT REQUIREMENTS

## Core model
Reality is the reference. Both the user's understanding and Athena's understanding are models that can be wrong.

At minimum preserve separate representations:
- FACT / EVENT
- OBSERVATION
- USER_HYPOTHESIS
- ATHENA_HYPOTHESIS
- EVIDENCE
- DECISION
- INTERVENTION / TEST
- EXPECTED OUTCOME
- ACTUAL OUTCOME
- LEARNING
- TARGET_STATE

## Required properties
Material claims should retain provenance, temporal scope and confidence/uncertainty where relevant.

Historical hypotheses must never silently become historical facts.

Athena should be able to reach any of these states:
- user model more accurate;
- Athena model more accurate;
- both partially right;
- both wrong;
- unresolved.

The system should preserve divergence rather than forcing premature convergence.

## Working-model loop
Current state → hypotheses → competing explanations → evidence → intervention/test → outcome → learning → model update → target-state review.

This loop is a behavioural requirement. The physical implementation remains open.
