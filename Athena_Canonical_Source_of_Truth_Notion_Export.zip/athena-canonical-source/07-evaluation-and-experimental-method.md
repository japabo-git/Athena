# 07 — Evaluation & Experimental Method

**Label:** CURRENT REQUIREMENT — NEW BASELINE

## Experimental baseline
The baseline is **raw base model + frozen synthetic scenario**.

No Athena prompt. No memory system. No retrieval. No orchestration. No hidden behavioural scaffolding.

## Experiment sequence
1. Establish repeated raw-model baseline.
2. Build a failure map across behavioural capabilities.
3. Select the highest-value failures for intervention.
4. Test single-capability prompt additions against the same baseline cases.
5. Replicate promising effects across independent scenario families.
6. Combine only capabilities with demonstrated marginal value.
7. Test longitudinal scenarios and outcome-driven updating.

## Evaluation principles
- Prefer atomic observable checks.
- Use deterministic checks where possible.
- Use structured rubrics where interpretation is unavoidable.
- Never rely solely on an unconstrained “quality” score.
- Preserve raw model outputs.
- Separate generator from evaluator where practical.
- Report uncertainty and evaluator disagreement.
- Do not optimise a single aggregate score at the expense of understanding failure modes.

The previous experiment matrix is historical and is not the canonical starting point.
