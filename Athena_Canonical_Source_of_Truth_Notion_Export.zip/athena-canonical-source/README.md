# Athena — Canonical Source of Truth

This directory is an export of the current **ATHENA — CANONICAL SOURCE OF TRUTH** workspace in Notion, fetched on 2026-09-22.

## Important
- This export is a **snapshot**, not a competing source of truth.
- Canonical authority remains the Notion workspace.
- Historical material is represented only where the canonical archive page explicitly references it.
- Runtime/implementation systems are not included because the canonical source states they are execution/evidence systems rather than the specification.

## Structure
- `ATHENA-CANONICAL-SOURCE-OF-TRUTH.md` — governing index and rules
- `00`–`14` — canonical sections
- `manifest.json` — export metadata
