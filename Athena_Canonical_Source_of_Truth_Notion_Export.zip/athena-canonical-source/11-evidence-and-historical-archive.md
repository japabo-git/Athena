# 11 — Evidence & Historical Archive

**Label:** ARCHIVE / EVIDENCE

This area contains historical Athena material retained for provenance and learning.

Historical material is not current authority unless explicitly promoted into the canonical pages.

Primary historical sources currently include:
- META-ATHENA-HARNESS and its child pages/databases
- First Vertical Slice & Synthetic Evaluation specification
- Experiment runner and screening artefacts
- Dropbox Athena Worker Lab
- implementation/deployment records from Railway, AppDeploy, Floot and related environments

Archive rule: preserve evidence; never rewrite history to match the current design.

Referenced historical pages:
- META-ATHENA-HARNESS — Source of Truth
- Athena Experimental Lab — Control Board
- SOP — Autonomous Experiment Execution & External Verification
- HISTORICAL — Agent Execution Lifecycle Architecture Guide
