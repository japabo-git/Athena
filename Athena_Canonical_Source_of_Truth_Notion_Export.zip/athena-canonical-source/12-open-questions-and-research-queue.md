# 12 — Open Questions & Research Queue

**Label:** OPEN QUESTIONS

Questions belong here until answered by evidence or an explicit decision.

Initial questions:
- Which behavioural capabilities genuinely require prompt intervention beyond the raw model?
- Which behaviours can be reliably evaluated with objective/atomic checks?
- Which scenarios require longitudinal multi-turn testing?
- What minimum memory capabilities are actually required after behavioural testing?
- What architecture is justified by demonstrated requirements?
- What execution environment provides sufficient reproducibility without becoming the project itself?
