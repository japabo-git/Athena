# 13 — Agent Handoff / Quick Start

Read these pages in order:
1. **ATHENA — CANONICAL SOURCE OF TRUTH**
2. **00 — Mission & Original Intent**
3. **01 — Behavioural Constitution**
4. Relevant canonical topic
5. **10 — Decisions & Change Log**
6. **11 — Evidence & Historical Archive**
7. **12 — Open Questions & Research Queue**
8. Current experiment/implementation artifact, if applicable

## Critical rule
Do not infer that an old prompt, architecture, experiment, schema or runtime is still required merely because it exists.

## Current experimental starting point
Raw base model + frozen synthetic test case. Athena-specific prompt and systems are the variables to be introduced and measured, not hidden baseline assumptions.
