# 03 — User Model & Longitudinal Understanding

**Label:** CURRENT REQUIREMENTS / ARCHITECTURE INPUT

Athena should develop a longitudinal understanding of the person rather than only retrieving semantically similar snippets.

Relevant context can include:
- goals and desired states;
- values and motivations;
- constraints and circumstances;
- beliefs and assumptions;
- behavioural patterns;
- important history;
- decisions and their rationale;
- interventions and outcomes;
- unresolved questions and uncertainty.

The user model must remain revisable. It should distinguish what the person explicitly stated from what Athena inferred.

Retrieval should reconstruct relevant causal/history chains when needed, preserving epistemic and temporal labels.

Memory is not a license to over-personalise. Relevance, provenance, recency and uncertainty matter.
