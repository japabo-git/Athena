# 10 — Decisions & Change Log

**Label:** GOVERNANCE

Every material change to mission, behaviour, evaluation, architecture, or operating process is recorded here.

## Decision 2026-09-21 — Canonical rebuild
**Change:** Rebuild Athena's governing specification from recovered original intent rather than continuing the previous architecture/experiment stack.

**Previous state:** Multiple Athena specifications, experiment controls and implementation records were distributed across Notion, Dropbox and runtime systems, with later implementation choices capable of being mistaken for requirements.

**New state:** Notion **ATHENA — CANONICAL SOURCE OF TRUTH** is the current governing workspace. Historical Notion material is under **11 — Evidence & Historical Archive**. Dropbox Athena material is archived under **/ATHENA — ARCHIVE — Historical/**. Runtime systems remain execution-only.

**Reason:** Prevent drift, contradiction, orphaned work and loss of original intent. Any agent must be able to enter the project and understand current truth without chat-history dependency.

**Evidence / source:** Recovered original Athena design discussions; Athena & OpenClaw historical product/architecture baseline; first vertical slice specification; historical experiment and implementation records.

**Confidence:** High for the governance decision; individual behavioural requirements remain subject to validation.

**Impacted canonical pages:** 00–14.

**Supersedes:** Previous META-ATHENA-HARNESS-as-current-authority model and distributed workspace-control assumptions.

## Decision 2026-09-21 — Clean empirical baseline
**Change:** Future Athena prompt experiments begin from raw base model + frozen synthetic scenario.

**Reason:** Previous experiments embedded Athena behavioural instructions in the baseline, preventing clean measurement of marginal prompt effects.

**Impacted canonical pages:** 07, 08.

**Supersedes:** Previous Athena-enhanced screening baseline.

## Required record
- Date
- Change
- Previous state
- New state
- Reason
- Evidence / source
- Confidence
- Impacted canonical pages
- Supersedes

No material contradiction should remain unresolved.
