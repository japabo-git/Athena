# ATHENA — CANONICAL SOURCE OF TRUTH

**State:** ACTIVE — canonical rebuild  
**Version:** 0.1  
**Authority:** This workspace is the current source of truth for Athena.  
**Last rebuilt:** 2026-09-21

## Purpose
Athena exists to help a person move toward an evolving **best self / genuinely desired future**, rather than merely complete tasks or satisfy the person's immediate requests.

This workspace is intentionally rebuilt from the original product intent and recovered design discussions. Existing architectures, prompts, experiment harnesses, runtime choices, and implementation decisions are **historical evidence, not requirements** unless explicitly promoted here.

## First-principles operating rule
> **Any agent entering this project must be able to understand what Athena is, why it exists, what is currently believed, what is proven, what is uncertain, and what must happen next without relying on chat history.**

## Canonical hierarchy
1. Mission & identity
2. Behavioural constitution
3. User / world model
4. Desired states and decision principles
5. Memory and learning requirements
6. Evaluation specification
7. Architecture hypotheses
8. Implementation
9. Experiments and evidence

Lower layers must not silently redefine higher layers.

## Evidence labels
- **ORIGINAL INTENT** — recovered from the earliest Athena discussions; strongest source for why Athena exists and intended behaviour.
- **CURRENT REQUIREMENT** — deliberately accepted as part of the current canonical design.
- **HYPOTHESIS** — plausible but not yet demonstrated.
- **EXPERIMENTAL FINDING** — supported by an executed experiment.
- **IMPLEMENTATION HISTORY** — historical implementation detail; not binding.
- **OPEN QUESTION** — unresolved and intentionally not guessed.

## Change-control rule
Every agent working on Athena MUST:
1. Read this page first.
2. Read the relevant canonical section before changing anything.
3. Search existing decisions/evidence before proposing a new design.
4. Never silently create a competing source of truth.
5. Record material changes as a decision with rationale, evidence and status.
6. Update affected canonical documents in the same work session.
7. Label assumptions and hypotheses explicitly.
8. Preserve historical material; do not overwrite evidence to make the new design look cleaner.
9. Leave the workspace internally coherent before handing work back.
10. If a conflict cannot be resolved from evidence, record it as an OPEN QUESTION rather than choosing silently.

## Current rebuild rule
We are **not reusing the previous experiment design as the starting point**. The first empirical experiment after this rebuild begins with:

**raw base model + frozen synthetic test case**

No Athena prompt, memory system, orchestration, retrieval layer, or other Athena-specific machinery is included in the baseline unless the experiment explicitly says so.

## Source-system policy
**Notion is the canonical human-readable project control plane.**

Dropbox, repositories, deployment platforms and experiment runtimes are execution/evidence systems only. They must not become competing specifications.

Canonical requirements should be readable in Notion and exportable into files for any external agent/runtime when needed.

## Definition of done for this rebuild
The rebuild is complete only when:
- original intent has been recovered and reconciled;
- current requirements are explicitly separated from historical hypotheses;
- behavioural requirements are complete enough to evaluate;
- evaluation methodology is independently reproducible;
- architecture is derived from demonstrated requirements;
- agent operating procedures prevent drift and orphaned work;
- historical systems are clearly archived and labelled;
- another agent can enter from this page and continue without chat-history dependency.
