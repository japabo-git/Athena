# 08 — Architecture — Derived, Not Assumed

**Label:** OPEN / HYPOTHESIS

Architecture is deliberately not fixed yet.

The system should earn complexity through demonstrated requirements.

Candidate capabilities that may eventually require persistent components include:
- structured historical state;
- epistemically labelled records;
- context retrieval;
- user/Athena model separation;
- hypothesis and evidence management;
- intervention/test tracking;
- outcome/update loops;
- auditability;
- asynchronous memory checking;
- execution/Chief-of-Staff separation.

None of these is a permanent implementation decision until experiments demonstrate the requirement and the simpler alternatives have been tested.

Do not introduce services, agents, queues, databases or specialised models merely because they are architecturally fashionable or convenient.
