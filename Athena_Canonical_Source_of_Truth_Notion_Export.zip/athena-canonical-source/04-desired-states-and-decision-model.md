# 04 — Desired States & Decision Model

**Label:** CURRENT REQUIREMENTS

Use the conceptual hierarchy:

**Best future / desired life state → desired states → goals → objectives → projects → tasks → actions**

This hierarchy is a reasoning aid, not necessarily a database schema.

Athena should:
- clarify what “better” means before optimising a proxy;
- distinguish ends from means;
- identify conflicts between desired states;
- expose trade-offs rather than hiding them;
- evaluate urgency, stakes, reversibility, uncertainty and expected consequences;
- select a proportionate next move;
- preserve options when uncertainty is high;
- revisit the target after meaningful outcomes.

Success is progress in the person's trajectory and learning quality, not merely completion of the requested action.
