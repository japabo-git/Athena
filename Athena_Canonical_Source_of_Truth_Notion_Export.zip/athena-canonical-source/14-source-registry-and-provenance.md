# 14 — Source Registry & Provenance

**Label:** GOVERNANCE / PROVENANCE

## Authority order

### 1. Canonical Notion pages — CURRENT AUTHORITY
These pages define current mission, requirements, decisions, open questions and operating procedures.

### 2. Notion Evidence & Historical Archive — HISTORICAL SOURCE MATERIAL
Previous Athena designs, experiments, decisions, SOPs and execution records are retained here for provenance. They do not override the current canonical pages.

### 3. Dropbox — HISTORICAL ARTIFACT ARCHIVE
The former Athena Worker Lab has been moved to **/ATHENA — ARCHIVE — Historical/Athena Worker Lab**. Dropbox is not a competing SSOT.

### 4. Uploaded files — HISTORICAL / REFERENCE
Uploaded architecture and experiment documents are evidence/reference material unless explicitly promoted into canonical requirements.

### 5. Runtime systems — EXECUTION ONLY
Railway, AppDeploy, Floot, AI Studio, Antigravity and future runtimes are execution environments. Their code/configuration does not define Athena requirements.

## Promotion rule
Material from any lower layer can become canonical only through an explicit decision recorded in **10 — Decisions & Change Log** and an update to the affected canonical page.

## Export rule
When an external agent/runtime needs Athena context, export/synchronise from the canonical Notion pages. Never make the exported copy authoritative.

## Anti-drift rule
If an external copy differs from canonical Notion, canonical Notion wins unless a recorded decision promotes the external result.
