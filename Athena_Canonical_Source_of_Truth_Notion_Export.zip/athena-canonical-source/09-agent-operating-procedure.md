# 09 — Agent Operating Procedure

**Label:** MANDATORY PROCESS

Every agent working on Athena follows this procedure.

## Before work
1. Read **ATHENA — CANONICAL SOURCE OF TRUTH**.
2. Read the relevant canonical section(s).
3. Search Decisions, Evidence and Open Questions.
4. Inspect current implementation/experiment state only after understanding the canonical requirement.
5. Identify whether the requested work is: requirement, hypothesis, experiment, implementation, evidence, or maintenance.

## During work
- Do not create a second specification.
- Do not silently reinterpret a requirement.
- Label assumptions explicitly.
- Preserve raw evidence.
- Record important failures, not only successes.
- If changing a canonical requirement, record rationale and evidence.
- If implementation contradicts canonical requirements, fix the implementation or record an explicit decision; never let the contradiction persist silently.

## Before handoff
- Update the affected canonical page(s).
- Record material decisions and evidence.
- Link artifacts/results to their canonical topic.
- Mark superseded material rather than deleting history.
- Confirm there is one obvious current answer to each material question.
- Leave a concise next-state summary.

## Anti-orphan rule
A new document, experiment, prompt, schema, skill or implementation artifact is incomplete until it has:
- an owner/context;
- a purpose;
- a status label;
- a canonical home or explicit archive location;
- a relationship to the current requirements;
- and a clear supersession rule.

## Conflict rule
If two canonical documents conflict, stop treating either as authoritative until the conflict is resolved and recorded in Decisions. Never resolve conflicts by silently choosing the newest file.
